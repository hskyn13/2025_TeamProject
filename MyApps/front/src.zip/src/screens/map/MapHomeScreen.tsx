import React from 'react';
import { StyleSheet, View, Text } from 'react-native';



function MapHomeScreen() {
  return (
    <View>
        
        <Text>맵 스크린

        </Text>

    </View>
  );
} 

const styles = StyleSheet.create({});

export default MapHomeScreen;
import React from 'react';
import {StyleSheet, View , Text} from 'react-native';


function CalendarHomeScreen() {
  return (
    <View>
        <Text>캘린더</Text>

    </View>
  )
}

const styles = StyleSheet.create({});

export default CalendarHomeScreen;